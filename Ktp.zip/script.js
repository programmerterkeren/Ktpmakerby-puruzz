
    (function(){
      // ===== PARTICLE BG (Bottom to Top) =====
      const canvasP = document.getElementById('particles-canvas');
      const ctxP = canvasP.getContext('2d');
      let w, h;
      
      function resize() {
        w = canvasP.width = window.innerWidth;
        h = canvasP.height = window.innerHeight;
      }
      window.addEventListener('resize', resize);
      resize();

      const particles = Array.from({ length: 110 }, () => ({
        x: Math.random() * w,
        y: h + Math.random() * 100,
        vx: (Math.random() - 0.5) * 0.4,
        vy: -Math.random() * 0.8 - 0.3,
        r: Math.random() * 1.8 + 1.2,
        opacity: Math.random() * 0.5 + 0.2,
      }));

      function drawParticles() {
        ctxP.clearRect(0, 0, w, h);
        
        for (let p of particles) {
          p.x += p.vx;
          p.y += p.vy;
          
          if (p.y < -20) {
            p.y = h + Math.random() * 50;
            p.x = Math.random() * w;
            p.vy = -Math.random() * 0.8 - 0.3;
          }
          
          p.vx += (Math.random() - 0.5) * 0.02;
          p.vx = Math.max(-0.6, Math.min(0.6, p.vx));
          
          ctxP.beginPath();
          ctxP.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctxP.fillStyle = `rgba(56, 189, 248, ${p.opacity})`;
          ctxP.fill();
        }
        
        for (let i = 0; i < particles.length; i++) {
          for (let j = i + 1; j < particles.length; j++) {
            const dx = particles[i].x - particles[j].x;
            const dy = particles[i].y - particles[j].y;
            const dist = Math.hypot(dx, dy);
            if (dist < 100) {
              ctxP.beginPath();
              ctxP.moveTo(particles[i].x, particles[i].y);
              ctxP.lineTo(particles[j].x, particles[j].y);
              ctxP.strokeStyle = `rgba(56, 189, 248, ${0.04 * (1 - dist / 100)})`;
              ctxP.lineWidth = 0.5;
              ctxP.stroke();
            }
          }
        }
        requestAnimationFrame(drawParticles);
      }
      drawParticles();

      // ===== MUSIC TOGGLE =====
      const audio = document.getElementById('bg-music');
      const musicBtn = document.getElementById('musicToggle');
      let isPlaying = false;

      musicBtn.addEventListener('click', function(e) {
        e.preventDefault();
        if (isPlaying) {
          audio.pause();
          isPlaying = false;
          musicBtn.classList.remove('playing');
          musicBtn.innerHTML = '<i class="fas fa-music"></i>';
        } else {
          audio.play().catch(() => {});
          isPlaying = true;
          musicBtn.classList.add('playing');
          musicBtn.innerHTML = '<i class="fas fa-pause"></i>';
        }
      });

      // ===== WARNING POPUP =====
      const overlayW = document.getElementById('fun-warning-overlay');
      const popupW = document.getElementById('fun-warning-popup');
      const okBtn = document.getElementById('fun-warning-ok');
      setTimeout(() => {
        overlayW.classList.add('show');
        popupW.classList.add('show');
      }, 400);
      okBtn.addEventListener('click', function() {
        overlayW.classList.remove('show');
        popupW.classList.remove('show');
        audio.play().catch(() => {});
        isPlaying = true;
        musicBtn.classList.add('playing');
        musicBtn.innerHTML = '<i class="fas fa-pause"></i>';
      });
    })();
